package study;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class Authentication extends HttpServlet { 
	  private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    // Get the username and password from the request
	    String username = request.getParameter("username");
	    String password = request.getParameter("password");

	    // Perform authentication logic
	    if (username.equals("admin") && password.equals("password")) {
	      // Authentication success, redirect to the homepage
	      response.sendRedirect("index.jsp");
	    } else {
	      // Authentication failed, show an error message
	      request.setAttribute("error", "Invalid username or password.");
	      request.getRequestDispatcher("login.jsp").forward(request, response);
	    }
	  }
	}

}
